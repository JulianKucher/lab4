# kppLab4

![screenshot_2017-12-09-11-59-54-179_com kpp vntu lab4](https://user-images.githubusercontent.com/21161653/33794834-710bf84c-dcdc-11e7-9919-5e55bb6221dc.png)
