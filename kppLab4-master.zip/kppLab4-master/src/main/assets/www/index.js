function sayhello(){
alert('hi' + document.getElementById('name').value + '!')
}